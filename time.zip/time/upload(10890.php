<html>
<head>
<title>upload</title>
</head>
<body>
<form name="form1" method="post" action="upok.php" enctype="multipart/form-data">
	Password: <input type="text" name="pww"><br>
	<input type="file" name="fileUpload">
	<input name="btnSubmit" type="submit" value="Submit">
</form>
</body>
</html>